class hello ():
    def __init__(self,name,lol):
        self.name = name
        self.lol = lol


def main():

    yes = hello("nano",15)

    print(yes.name)

main()