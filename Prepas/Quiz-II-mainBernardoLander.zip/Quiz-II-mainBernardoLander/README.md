# Quiz-II
## Problema 1 (7pts):
Tienes la opción de elegir cualquiera de estos dos ejercicios para resolver (solo uno):

a) Desarrolla una función recursiva para ordenar los números contenidos en la lista dada.
***Nota:*** No está permitido usar el método .sort(), la built-in function sorted(), ni ningún tipo de algoritmo de ordenamiento.

b) Desarrolla una función recursiva que invierta el contenido del string dado.
***Nota:*** No está permitido utilizar `variable[::-1]`.

 
## Problema 2 (13pts + 2pts):
Un centro comercial te ha contratado para que elabores una aplicación que les permita administrar su servicio de estacionamiento. Dicho software debe contar con las siguientes funcionalidades:
- **Registro de vehículos:** a partir de la información de los vehículos contenida en la estructura de datos adjunta, deben crearse objetos y almacenarse en el programa. Hay dos tipos de vehículo: automóviles y motocicletas. Todos los vehículos tienen placa, marca, puesto, hora de entrada y hora de salida. Los automóviles, además, cuentan con la condición de ser o no para minusválidos.
- **Salida de vehículos:** debe existir la opción de mostrar la información de todos los vehículos que están estacionados, elegir al que se vaya a retirar, almacenar su hora de salida y borrar del objeto el puesto en el que estaba.
- **Ver vehículos:** deben mostrarse todos los vehículos que se encuentran en el estacionamiento (es decir, si algún vehículo tiene hora de salida y no tiene puesto, porque salió del estacionamiento, no debe mostrarse).

***BONO (+2):***
- Consumir la información de los vehículos a partir del archivo de texto adjunto en vez de usar la de la estructura de datos dada.
- Al final del día (cuando se vaya a cerrar el programa), guardar la información actualizada de los vehículos en un archivo de texto nuevo.
